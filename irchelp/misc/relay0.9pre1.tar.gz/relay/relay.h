/* relay.h -- various configuration options
 * 
 * IRC relay program
 * orig. by Rich Hecker <garf@flatcat.clo.com>
 * v1.1 by Rich Lafferty <lafferty@pobox.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License Version 1
 * as published by the Free Software Foundation.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 * 
 * Send your comments and all your spare pocket change to 
 * lafferty@pobox.com (Rich Lafferty) or garf@flatcat.clo.com
 * (Rich Hecker). Any donations are welcome.
 * --------------------------------------------------------------
 */

/* DEFAULTS --
 * The following set up the defaults for the commandline options.
 * DEFAULTHOST        hostname to appear as
 * DEFAULTSERVER      address of remote host  
 * DEFAULTPORT        port to connect to on remote host
 * DEFAULTUSEINLINE   Use inline (server:port) format by default
 */

#define DEFAULTHOST	  "198.168.183.73"      
#define DEFAULTSERVER     "flatcat.clo.com"
#define DEFAULTPORT       23            
#undef  DEFAULTUSEINLINE  


/* Put the IP address to listen on here.
 * This is usually your machine's address.
 */ 

#define LISTENINGIP     "198.168.183.73"


/* PRIVILEGED HOSTS --
 * The following set up restrictions on one hostname.
 * Only users that belong to the privileged group can use the hostname. 
 * LIMITEDGID	The privileged groupid that can use the hostname
 * LIMITEDHOST	The restricted-use address. 
 */
 
#define LIMITEDGID      0                       
#define LIMITEDHOST       "206.116.80.198"       


/* LOGGING --
 * The following determine the level of logging to use.
 * PRIVLOG	Log all attempts to use LIMITEDHOST         
 * STARTLOG	Log all incidences of the program
 * CONNECTLOG   Log all connections through the relay
 * (All are facility AUTHPRIV, priority INFO and ERROR)
 */

#define PRIVLOG
#define STARTLOG	
#define CONNECTLOG


/* Various parameters --
 * It shouldn't be necessary to change these.
 * TIMEOUT     Time to keep listening for connection to relay
 * BUFFERSIZE  Buffer for relay
 */

#define TIMEOUT         180   
#define BUFFERSIZE      256  

