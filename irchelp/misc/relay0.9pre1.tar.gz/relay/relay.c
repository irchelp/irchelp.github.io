/*
 * IRC relay program
 * orig. by Rich Hecker <garf@flatcat.clo.com>
 * v1.1 by Rich Lafferty <lafferty@pobox.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License Version 1
 * as published by the Free Software Foundation.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 * 
 * Send your comments and all your spare pocket change to 
 * lafferty@pobox.com (Rich Lafferty) or garf@flatcat.clo.com
 * (Rich Hecker). Any donations are welcome.
 * --------------------------------------------------------------
 */

#include <arpa/inet.h>
#include <ctype.h>
#include <grp.h>
#include <netdb.h>
#include <netinet/in.h>
#include <netinet/in.h>
#include <pwd.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/time.h>
#include <syslog.h>
#include <time.h>
#include <unistd.h>
#include <utmp.h>

#include "relay.h"

/* Some simple #define's */

#define TRUE		1
#define FALSE		0

/* Type(s) */

typedef int Error;
typedef unsigned long int Caddr;  

/* Prototypes */

int main (int, char **);
int initialize (void);
void parentstuff (int,int);
void childstuff(int, Caddr, Caddr, Caddr, int);
void relay(int, int);
Error handle(int, char**, Caddr*, Caddr*, int*, int*);
Caddr getipaddr(char*);
Error checkprivgrp(Caddr);

/* main(): Your average main() function... */

int main(int argc, char *argv[])
{
    int fork_res;
    int in_port, out_port;
    Caddr host, server; 
    int inline_out;
    
    /* Initialize parameters */
    out_port=DEFAULTPORT;
    host=getipaddr(DEFAULTHOST);
    server=getipaddr(DEFAULTSERVER);

#ifdef DEFAULTUSEINLINE
    inline_out=TRUE;
#else
    inline_out=FALSE;
#endif

    /* open syslog if necessary         */
    /* (it's necessary if fork() dies.) */
    openlog(argv[0],LOG_PID,LOG_AUTH);

    /* Set all necessary parameters */
    in_port = initialize();
    if(handle(argc,argv,&server,&host,&out_port,&inline_out)) 
    {
        if(checkprivgrp(host))
        {
        
            /* Lets fork */
            fflush(stdout);
            fork_res = fork();
            if (fork_res == -1) 
            {         
               syslog(LOG_ERR,"could not fork");
               printf("%s: could not fork",argv[0]);
               return 1;
            }
            if (fork_res) 
                parentstuff(in_port,inline_out);
            else
                childstuff(in_port, getipaddr(LISTENINGIP), host,
                           server, out_port);
            return 0;
        }
        else
        {
            printf("%s: you are not allowed to use that hostname with -h\n",
                    argv[0]);
            return 1;
        }  
    }
    else 
    {
        return 1;
    }
}

/* initialize(): Seeds random number generator, picks port and passwd */
int initialize() 
{
    int port;

    /* Seed random number generator */
    srand((unsigned int) getpid());

    /* Pick a random port */
    port = rand() % 40000 + 20000;

    /* Inform the world */
#ifdef STARTLOG
        syslog(LOG_INFO,"started by %s (uid %i)",
               getpwuid(getuid())->pw_name,getuid());
#endif

    return port;

}

/* handle: parse commandline arguments */
Error handle(int argc, char *argv[], Caddr *server, Caddr *host, 
             int *port, int *inline_output)
{
    int i;    /*count*/

    for(i=1;i<=argc-1;i++)
    {
        if((strcmp(argv[i],"-s")==0) && (argv[i+1]!=NULL))      
            *server=getipaddr(argv[++i]);
        else if((strcmp(argv[i],"-h")==0) && (argv[i+1]!=NULL))  
            *host=getipaddr(argv[++i]);
        else if((strcmp(argv[i],"-p")==0) && (argv[i+1]!=NULL))
            *port=atoi(argv[++i]);
        else if(strcmp(argv[i],"-i")==0) 
#ifdef DEFAULTUSEINLINE
                *inline_output=FALSE;
#else        
                *inline_output=TRUE;
#endif
        else if(strcmp(argv[i],"--help")==0)
        {
            printf("%s: usage: %s [[-i] [-h hostname] [-s server] [-p port]] [--help]\n\n",argv[0],argv[0]);
#ifdef DEFAULTUSEINLINE 
                printf(" -i                    Use verbose output format\n");
#else
                printf(" -i                    Use inline (server:port) output format\n");
#endif
            printf(" -h HOSTNAME           Relay as HOSTNAME instead of default\n");
            printf(" -s SERVER             Relay to remote host SERVER\n");
            printf(" -p PORT               Connect to port PORT on remote host\n\n");  
            printf(" --help                Show this help text\n");
            printf(" --version             Show version information\n\n");
            printf(" Report bugs to lafferty@pobox.com.\n\n"); 
            return 0;
        }
        else if(strcmp(argv[i],"--version")==0)
        { 
            printf("Relay 0.9pre1\n");
            return 0;
        }
        else 
        {
            printf("%s: usage: %s [[-i] [-h hostname] [-s server] [-p port]] [--help]\n",argv[0],argv[0]);
            return 0;
        }
    }
    return 1;
}

/* getipaddr: convert hostname into address */
Caddr getipaddr(char *host)
{
    Caddr address;
    struct hostent *getipad;

    getipad = gethostbyname(host);
    address=((struct in_addr *)getipad->h_addr)->s_addr;
    return address;
}

/* parentstuff: print details for user */
void parentstuff(int port,int inline_output) 
{
    if(inline_output==TRUE)
       printf(LISTENINGIP":%d\n",port);
    else
       printf("You have %.1f minutes to connect to port %d at\n"LISTENINGIP"\n",
              TIMEOUT / 60.0,port);
}

/* childstuff(): Actually sets up and runs the relay. */
void childstuff(int port, Caddr waitaddr, Caddr host, Caddr server, 
                int serverport) 
{
    struct sockaddr_in serveraddr, 
                       clientaddr;
    int listenfd,
        clientfd,
        clientlen,
        serverfd;

#ifdef CONNECTLOG 
        struct in_addr toclient,
                       fromclient,
                       toserver,
                       fromserver; 

    char *a,*b,*c,*d;  /* for syslog/inet_ntoa kludge below */
#endif

    fd_set testconnect;
    struct timeval timeout;

    signal(SIGHUP, SIG_IGN);

    listenfd = socket(AF_INET, SOCK_STREAM, 0);
    serveraddr.sin_family = AF_INET;
    serveraddr.sin_addr.s_addr = waitaddr;
    serveraddr.sin_port = htons(port);
#ifdef CONNECTLOG
        toclient.s_addr=serveraddr.sin_addr.s_addr;
#endif
    bind(listenfd, (struct sockaddr *) &serveraddr, sizeof(serveraddr));

    /* Listen to the port */
    listen(listenfd, 1);

    /* Wait for a connection */
    FD_ZERO(&testconnect);
    FD_SET(listenfd, &testconnect);
    timeout.tv_sec = TIMEOUT;
    timeout.tv_usec=0;
    select (FD_SETSIZE, &testconnect, (fd_set *) 0, (fd_set *) 0,
            &timeout);
    if (!FD_ISSET(listenfd,&testconnect)) 
        exit(0);

    clientfd = accept(listenfd, (struct sockaddr *) &clientaddr,
                      &clientlen);
#ifdef CONNECTLOG
        fromclient.s_addr=clientaddr.sin_addr.s_addr;
#endif
    serverfd = socket(AF_INET, SOCK_STREAM, 0);

    serveraddr.sin_addr.s_addr = host;
    serveraddr.sin_port = htons(rand() % 40000 + 10000);
    bind(serverfd, (struct sockaddr *) &serveraddr, sizeof(serveraddr));
#ifdef CONNECTLOG
        fromserver.s_addr=serveraddr.sin_addr.s_addr;
#endif
    serveraddr.sin_addr.s_addr = server;
    serveraddr.sin_port = htons(serverport);


    connect(serverfd, (struct sockaddr *)&serveraddr, sizeof(serveraddr));

#ifdef CONNECTLOG
        toserver.s_addr=serveraddr.sin_addr.s_addr; 

        /* Can you say dirty hack? */
        syslog(LOG_INFO,"[client] %s <> %s / %s <> %s [server]",
            a=strdup(inet_ntoa(fromclient)),
            b=strdup(inet_ntoa(toclient)),
            c=strdup(inet_ntoa(fromserver)),
            d=strdup(inet_ntoa(toserver)));
        free(a);free(b);free(c);free(d);   
#endif

    relay(serverfd, clientfd);

    close(clientfd);
}

/* relay: move the data */

void relay(int serverfd, int clientfd) 
{
    fd_set inputs, testfds;
    int nread;
    char buffer[BUFFERSIZE];

    FD_ZERO(&inputs);
    FD_SET(serverfd, &inputs);
    FD_SET(clientfd, &inputs);

    while(1) 
    {
        testfds = inputs;
        select(FD_SETSIZE, &testfds, (fd_set *) 0, (fd_set *) 0,
               (struct timeval *) 0);
        if (FD_ISSET(clientfd, &testfds)) 
        {
            nread = read(clientfd, buffer, BUFFERSIZE);
            if (!nread)
                exit(1);
            write(serverfd, buffer, nread);
        }
        if (FD_ISSET(serverfd, &testfds)) 
        {
            nread = read(serverfd, buffer, BUFFERSIZE);
            if (!nread)
                exit(1);
            write(clientfd, buffer, nread);
        }
    }
}

/* checkprivgrp: checks if user is in privileged group */ 
Error checkprivgrp(Caddr host)
{
    struct passwd *my_pw;
    struct group *priv_grp;
    int i=0;

    if(host==getipaddr(LIMITEDHOST))
    {
        /* get data to work with */
        my_pw=getpwuid(geteuid());
        priv_grp=getgrgid(LIMITEDGID);

        /* extract necessary details */
        while(priv_grp->gr_mem[i]!=NULL){
            if (strcmp(priv_grp->gr_mem[i++],my_pw->pw_name)==0) 
            {
#ifdef PRIVLOG
		    syslog(LOG_INFO,"privileged success");
                #endif
		return TRUE;
	    }	
        }
#ifdef PRIVLOG
            syslog(LOG_INFO,"privileged FAILED");
#endif    
        return FALSE;
    }
    return TRUE;
}
