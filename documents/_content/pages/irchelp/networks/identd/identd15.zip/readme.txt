Unzip this program into a directory, like "C:\Program Files\Identd".  

Please read the documentation under Documentation\readme.html for further instructions.
