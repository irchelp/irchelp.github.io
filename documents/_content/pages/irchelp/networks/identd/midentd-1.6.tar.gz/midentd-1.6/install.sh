#!/bin/sh
echo Installing midentd...
cp -vi midentd.conf midentd.mircusers /etc
touch /var/log/midentd.log
chown nobody /var/log/midentd.log
echo /var/log/midentd.log created and chowned to nobody
cp -v midentd midentd.logcycle /usr/local/sbin
mkdir /usr/doc/midentd
cp -v CHANGES README LICENSE /usr/doc/midentd
echo
echo Now, edit /etc/midentd.* and /etc/inetd.conf, and perhaps add
echo midentd.logcycle to roots crontab.
